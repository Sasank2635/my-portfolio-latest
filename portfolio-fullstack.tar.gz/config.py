"""
config.py — Central configuration for the portfolio.

All personal data, project info, skills, and experience live here.
Edit this file (or override via .env) to customize your portfolio.
"""

import os
from dotenv import load_dotenv

load_dotenv()


# ── App Settings ──────────────────────────────────────────────
DEBUG = os.getenv("DEBUG", "false").lower() == "true"
HOST = os.getenv("HOST", "0.0.0.0")
PORT = int(os.getenv("PORT", 8000))

# ── Personal ──────────────────────────────────────────────────
SITE_TITLE = os.getenv("SITE_TITLE", "Portfolio — DevOps · Backend · Agentic AI")
YOUR_NAME = os.getenv("YOUR_NAME", "Your Name")
YOUR_TITLE = os.getenv("YOUR_TITLE", "DevOps · Backend · Agentic AI Engineer")
YOUR_EMAIL = os.getenv("YOUR_EMAIL", "hello@yourdomain.com")
YOUR_LOCATION = os.getenv("YOUR_LOCATION", "Kolkata, India")

# ── Social Links ──────────────────────────────────────────────
SOCIAL_LINKS = {
    "github": os.getenv("GITHUB_URL", "https://github.com/yourusername"),
    "linkedin": os.getenv("LINKEDIN_URL", "https://linkedin.com/in/yourprofile"),
    "twitter": os.getenv("TWITTER_URL", "https://twitter.com/yourhandle"),
}

# ── SMTP (Contact Form) ──────────────────────────────────────
SMTP_HOST = os.getenv("SMTP_HOST", "smtp.gmail.com")
SMTP_PORT = int(os.getenv("SMTP_PORT", 587))
SMTP_USER = os.getenv("SMTP_USER", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
CONTACT_RECIPIENT = os.getenv("CONTACT_RECIPIENT", YOUR_EMAIL)

# ── Hero Metrics ──────────────────────────────────────────────
METRICS = [
    {"value": 50, "label": "Projects Shipped", "suffix": "+"},
    {"value": 99, "label": "Uptime Delivered", "suffix": "%"},
    {"value": 5, "label": "Years Experience", "suffix": "+"},
]

# ── About Cards ───────────────────────────────────────────────
ABOUT_CARDS = [
    {
        "icon": "⚙️",
        "theme": "devops",
        "title": "DevOps Engineering",
        "desc": "CI/CD pipelines, container orchestration, IaC, monitoring & observability at scale",
    },
    {
        "icon": "🔧",
        "theme": "backend",
        "title": "Backend Development",
        "desc": "High-performance APIs, microservices, event-driven architectures, database design",
    },
    {
        "icon": "🤖",
        "theme": "ai",
        "title": "Agentic AI",
        "desc": "Autonomous agents, tool-use chains, RAG systems, multi-agent orchestration",
    },
]

# ── Skills ────────────────────────────────────────────────────
SKILLS = [
    {
        "icon": "⚙️",
        "title": "DevOps & Cloud",
        "tags": [
            "Docker", "Kubernetes", "Terraform", "Ansible",
            "AWS", "GCP", "GitHub Actions", "Jenkins",
            "ArgoCD", "Prometheus", "Grafana", "Helm",
        ],
    },
    {
        "icon": "🔧",
        "title": "Backend & Data",
        "tags": [
            "Python", "Go", "Node.js", "FastAPI",
            "Django", "PostgreSQL", "Redis", "Kafka",
            "gRPC", "REST", "GraphQL", "MongoDB",
        ],
    },
    {
        "icon": "🤖",
        "title": "AI & ML",
        "tags": [
            "LangChain", "LangGraph", "CrewAI", "OpenAI API",
            "Claude API", "RAG", "Vector DBs", "HuggingFace",
            "PyTorch", "MLflow", "Function Calling", "AutoGen",
        ],
    },
]

# ── Projects ──────────────────────────────────────────────────
PROJECTS = [
    {
        "number": "01",
        "title": "Autonomous DevOps Agent",
        "desc": (
            "An AI agent that monitors infrastructure, diagnoses incidents, "
            "and auto-remediates — reducing MTTR by 73%. Uses multi-step "
            "reasoning with tool-use chains."
        ),
        "tech": ["Python", "LangGraph", "Kubernetes", "Prometheus", "Claude API"],
        "link": "#",
    },
    {
        "number": "02",
        "title": "Multi-Agent Code Review",
        "desc": (
            "A fleet of specialized AI agents that review PRs for security, "
            "performance, and style — each with domain expertise and "
            "collaborative consensus."
        ),
        "tech": ["CrewAI", "FastAPI", "GitHub API", "Redis", "Docker"],
        "link": "#",
    },
    {
        "number": "03",
        "title": "Zero-Downtime Deploy Pipeline",
        "desc": (
            "End-to-end GitOps pipeline with canary deployments, automated "
            "rollbacks, and real-time observability. Handles 50K+ deploys/year "
            "across 200+ services."
        ),
        "tech": ["ArgoCD", "Terraform", "Helm", "Istio", "Grafana"],
        "link": "#",
    },
    {
        "number": "04",
        "title": "RAG Knowledge Platform",
        "desc": (
            "Enterprise knowledge base with intelligent retrieval, contextual "
            "chunking, and agentic query planning. Serves 10K+ queries/day "
            "with sub-second latency."
        ),
        "tech": ["LangChain", "Pinecone", "FastAPI", "PostgreSQL", "React"],
        "link": "#",
    },
]

# ── Experience ────────────────────────────────────────────────
EXPERIENCE = [
    {
        "date": "2023 — Present",
        "role": "Senior AI & DevOps Engineer",
        "company": "TechCorp AI — Remote",
        "desc": (
            "Leading the agentic AI platform team. Architecting autonomous "
            "systems for infrastructure management and intelligent code "
            "generation pipelines."
        ),
    },
    {
        "date": "2021 — 2023",
        "role": "Backend Engineer",
        "company": "ScaleUp Systems — Bangalore",
        "desc": (
            "Built high-throughput microservices handling 1M+ RPM. Designed "
            "event-driven architectures with Kafka and implemented distributed "
            "tracing."
        ),
    },
    {
        "date": "2019 — 2021",
        "role": "DevOps Engineer",
        "company": "CloudNine Infra — Kolkata",
        "desc": (
            "Managed Kubernetes clusters across AWS and GCP. Built CI/CD "
            "pipelines and established SRE practices reducing downtime by 95%."
        ),
    },
]
